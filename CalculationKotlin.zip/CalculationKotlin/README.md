# Calculator

<a href="https://play.google.com/store/apps/details?id=com.dev_marinov.calculationkotlin"> ![GPLAY](https://user-images.githubusercontent.com/61028366/127751951-1b8e413b-ed07-4582-8550-d56ae601f112.png)
 >></a>
## Описание 
Приложение калькулятор выполняет самые простые вычисления, которые требуются каждый день. 
При выходе из приложения будет показан диалог согласиться или нет.

## Работа с кодом 
Клиентская часть: android studio kotlin

## Скрины экрана 
![1](https://user-images.githubusercontent.com/61028366/148612043-4ab4698c-57fb-41a1-b693-7f8d205b3c36.jpg)
![2](https://user-images.githubusercontent.com/61028366/148612046-017cca99-748b-4329-a157-51146d09b2dd.jpg)
![3](https://user-images.githubusercontent.com/61028366/148612049-1a4b051a-39f0-4754-b1fa-8e981011533f.jpg)
